# Time Series Predictions using Bidirectional LSTM
Submission 2 - Time Series Belajar Pengembangan Machine Learning - Dicoding \
Author : Hazmi Cokro

Dataset : "https://data.world/data-society/global-climate-change-data"

MAE < 10 %
- [x] Mae     : 2.2 
- [x] Val_mae : 2.3
